// 💰 पैकेजेस कॉन्फ़िगरेशन
const plans: Record<string, { amt: number }> = { 
    pack1: { amt: 100 },  
    pack2: { amt: 500 },  
    pack3: { amt: 1000 } 
}; 

// यूज़र का लाइव डेटा (डमी आईडी और वॉलेट बैलेंस)
let user = { 
    userId: "731940866", 
    roi: 100.00,        // वॉलेट बैलेंस (कमीशन इसी में जुड़ेगा)
    betColor: null as string | null, 
    directReferrals: 0,  // कुल सफल रेफरल
    hasInvested: false   // इन्वेस्टमेंट ट्रैकर (विड्रॉवल के लिए अनिवार्य)
}; 

let time = 60, period = 101, adminFix: string | null = null, timer: any;

// 🎮 दमन/तिरंगा स्टाइल गेम लूप
function start() {
    clearInterval(timer);
    time = 60;
    timer = setInterval(() => {
        time--;
        let timerDisp = document.getElementById("timer");
        if(timerDisp) timerDisp.innerText = `00:${time < 10 ? '0' + time : time}`;

        if (time <= 0) {
            clearInterval(timer);
            let winColor = adminFix ? adminFix : ['Green', 'Red', 'Violet'][Math.floor(Math.random() * 3)];
            let winNum = winColor === 'Green' ? [1,3,7,9][Math.floor(Math.random()*4)] : (winColor === 'Red' ? [2,4,6,8][Math.floor(Math.random()*4)] : [0,5][Math.floor(Math.random()*2)]);

            // टेबल रिकॉर्ड अपडेट
            let status = user.betColor ? (user.betColor === winColor ? ' Win' : ' Fail') : ' Done';
            let row = `<tr><td>${period}</td><td>${winNum}</td><td>${winColor}</td><td><strong>${status}</strong></td></tr>`;
            let recDisp = document.getElementById("records");
            if(recDisp) recDisp.innerHTML = row + recDisp.innerHTML;

            period++; user.betColor = null; adminFix = null; start();
        }
    }, 1000);
}

// 📈 इन्वेस्टमेंट फंक्शन (जब तक यूजर इन्वेस्ट नहीं करेगा, विड्रॉवल लॉक रहेगा)
function invest(planKey: string) {
    let p = plans[planKey];
    if(p && user.roi >= p.amt) {
        user.roi -= p.amt;
        user.hasInvested = true; // ✅ अब विड्रॉवल का रास्ता खुल गया

        let roiDisp = document.getElementById("roiDisp");
        if(roiDisp) roiDisp.innerText = `₹${user.roi.toFixed(2)}`;
        alert(`✅ निवेश सफल! आपका पैकेज एक्टिवेट हो गया है। अब आप विड्रॉवल कर सकते हैं।`);
    } else {
        alert("❌ निवेश के लिए आपके वॉलेट में पर्याप्त बैलेंस नहीं है!");
    }
}

// 👥 50% तुरंत डायरेक्ट रेफरल कमीशन लॉजिक
function simulateNewReferral(invitedPlanKey: string) {
    let p = plans[invitedPlanKey];
    if(p) {
        let commission = p.amt * 0.50; // सीधा 50% रेफरल इनकम
        user.roi += commission;       // वॉलेट में तुरंत क्रेडिट
        user.directReferrals += 1;    // रेफरल काउंट +1

        let roiDisp = document.getElementById("roiDisp");
        let refDisp = document.getElementById("refCountDisp");
        if(roiDisp) roiDisp.innerText = `₹${user.roi.toFixed(2)}`;
        if(refDisp) refDisp.innerText = `${user.directReferrals} लोग`;

        alert(`🎉 रेफरल सफल! आपके दोस्त के इन्वेस्ट करने पर आपको तुरंत 50% कमीशन (₹${commission}) मिल गया है!`);
    }
}

// 📤 सुरक्षित विड्रॉवल रूल्स इंजन (नो इन्वेस्टमेंट = नो विड्रॉवल)
function requestWithdrawal(amount: number) {
    if (!user.hasInvested) return alert("❌ सुरक्षा नियम: विड्रॉवल करने से पहले आपको गेम/ROI प्लान में कम से कम एक बार इन्वेस्ट करना ज़रूरी है!");
    if (user.directReferrals < 1) return alert("❌ नियम: विड्रॉवल के लिए आपके लिंक से कम से कम 1 डायरेक्ट मेंबर का होना ज़रूरी है!");
    if (new Date().getDay() === 0) return alert("❌ आज रविवार है, संडे को विड्रॉवल बंद रहता है!");
    if (amount < 200) return alert("❌ कम से कम ₹200 का विड्रॉवल होना ज़रूरी है!");
    if (user.roi < amount) return alert("❌ आपके वॉलेट में पर्याप्त बैलेंस नहीं है!");

    user.roi -= amount;
    alert(`🎉 ₹${amount} का विड्रॉवल सफल रहा। आपके खाते में राशि भेज दी गई है।`);
    let roiDisp = document.getElementById("roiDisp");
    if(roiDisp) roiDisp.innerText = `₹${user.roi.toFixed(2)}`;
}

function bet(c: string) { user.betColor = c; alert(`दांव लगा दिया: ${c}`); }
function fix(c: string) { adminFix = c; console.log(`फिक्स: ${c}`); }
start();